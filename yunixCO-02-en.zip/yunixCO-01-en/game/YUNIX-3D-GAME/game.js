"use strict";

/*
 * YUNIX 3D GAME v0.2
 * JavaScript Canvas 3D Block Engine
 * No external libraries
 */

(() => {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const statusEl = document.getElementById("status");
  const coordsEl = document.getElementById("coordinates");
  const blockSelect = document.getElementById("blockSelect");

  if (!canvas || !ctx) {
    console.error("YUNIX: Canvas not found!");
    return;
  }

  const FOV = Math.PI / 2.8;
  const textures = {};

  const texturePaths = {
    grass: "Assets/Textures/grass.png",
    dirt: "Assets/Textures/dirt.png",
    wood: "Assets/Textures/wood.png",
    glass: "Assets/Textures/glass.png",
    broken_stone: "Assets/Textures/broken_stone.png",
    microsoft: "Assets/Textures/microsoft.png"
  };

  const colors = {
    grass: "#58a83c",
    dirt: "#8b5a2b",
    wood: "#9a6a32",
    glass: "#9bd9e8",
    broken_stone: "#777777",
    microsoft: "#e8e8e8"
  };

  const world = new Map();
  const key = (x, y, z) => `${x},${y},${z}`;

  const player = {
    x: 0.5,
    y: 1.55,
    z: 5.5,
    yaw: 0,
    pitch: 0,
    speed: 3.4,
    verticalSpeed: 0,
    grounded: true
  };

  const keys = {};
  let joystick = { x: 0, y: 0 };
  let lookPointer = null;
  let lastLook = { x: 0, y: 0 };
  let lastFrame = performance.now();

  function setStatus(message) {
    if (statusEl) statusEl.textContent = message;
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth;
    const h = window.innerHeight;

    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  window.addEventListener("resize", resize);
  resize();

  // TEXTURES

  for (const [name, src] of Object.entries(texturePaths)) {
    const img = new Image();

    img.onload = () => {
      textures[name] = img;
    };

    img.onerror = () => {
      console.warn("Texture could not be loaded:", src);
    };

    img.src = src;
  }

  // BLOCK SYSTEM

  function addBlock(x, y, z, type = "grass") {
    x = Math.round(x);
    y = Math.round(y);
    z = Math.round(z);

    const id = key(x, y, z);

    if (world.has(id)) return false;

    world.set(id, {
      x, y, z,
      type: colors[type] ? type : "grass"
    });

    return true;
  }

  function removeBlock(block) {
    if (!block) return false;

    return world.delete(
      key(block.x, block.y, block.z)
    );
  }

  // WORLD GENERATOR

  function createWorld() {
    world.clear();

    for (let x = -7; x <= 7; x++) {
      for (let z = -7; z <= 7; z++) {
        addBlock(x, -1, z, "dirt");
        addBlock(x, 0, z, "grass");
      }
    }

    // Stone blocks
    addBlock(3, 1, 2, "broken_stone");
    addBlock(3, 2, 2, "broken_stone");
    addBlock(4, 1, 2, "broken_stone");

    // Tree
    addBlock(-3, 1, -2, "wood");
    addBlock(-3, 2, -2, "wood");
    addBlock(-3, 3, -2, "grass");

    // Special blocks
    addBlock(1, 1, -3, "glass");
    addBlock(2, 1, -3, "microsoft");
  }

  // 3D PROJECTION

  function project(x, y, z) {
    const dx = x - player.x;
    const dy = y - player.y;
    const dz = z - player.z;

    const cos = Math.cos(player.yaw);
    const sin = Math.sin(player.yaw);

    const rx = dx * cos - dz * sin;
    const rz = dx * sin + dz * cos;

    const cp = Math.cos(player.pitch);
    const sp = Math.sin(player.pitch);

    const ry = dy * cp - rz * sp;
    const depth = dy * sp + rz * cp;

    if (depth <= 0.08) return null;

    const width = window.innerWidth;
    const height = window.innerHeight;

    const focal =
      width * 0.5 / Math.tan(FOV * 0.5);

    return {
      x: width * 0.5 + rx * focal / depth,
      y: height * 0.5 - ry * focal / depth,
      depth
    };
  }

  // CUBE GEOMETRY

  const corners = [
    [-0.5,-0.5,-0.5],
    [ 0.5,-0.5,-0.5],
    [ 0.5, 0.5,-0.5],
    [-0.5, 0.5,-0.5],
    [-0.5,-0.5, 0.5],
    [ 0.5,-0.5, 0.5],
    [ 0.5, 0.5, 0.5],
    [-0.5, 0.5, 0.5]
  ];

  const faces = [
    { ids:[0,1,2,3], shade:0.78, neighbor:[0,0,-1] },
    { ids:[4,7,6,5], shade:0.88, neighbor:[0,0,1] },
    { ids:[0,4,5,1], shade:0.68, neighbor:[0,-1,0] },
    { ids:[3,2,6,7], shade:1.00, neighbor:[0,1,0] },
    { ids:[0,3,7,4], shade:0.82, neighbor:[-1,0,0] },
    { ids:[1,5,6,2], shade:0.90, neighbor:[1,0,0] }
  ];

  function faceVisible(block, face) {
    const [nx, ny, nz] = face.neighbor;

    return !world.has(
      key(
        block.x + nx,
        block.y + ny,
        block.z + nz
      )
    );
  }

  // FACE RENDERER

  function drawFace(points, block, shade, alpha = 1) {
    if (points.some(p => !p)) return;

    ctx.save();
    ctx.globalAlpha = alpha;

    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);

    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }

    ctx.closePath();

    const img = textures[block.type];

    if (img && img.complete && img.naturalWidth) {
      const pattern = ctx.createPattern(img, "repeat");
      ctx.fillStyle = pattern || colors[block.type];
    } else {
      ctx.fillStyle = colors[block.type];
    }

    ctx.fill();

    ctx.fillStyle =
      `rgba(0,0,0,${Math.max(0, 1 - shade)})`;

    ctx.fill();

    ctx.strokeStyle = "rgba(20,20,20,0.22)";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.restore();
  }

  function renderWorld() {
    const renderFaces = [];

    for (const block of world.values()) {
      for (const face of faces) {
        if (!faceVisible(block, face)) continue;

        const points = face.ids.map(i => {
          const c = corners[i];

          return project(
            block.x + c[0],
            block.y + c[1],
            block.z + c[2]
          );
        });

        if (points.some(p => !p)) continue;

        const depth =
          points.reduce((sum, p) => sum + p.depth, 0) /
          points.length;

        renderFaces.push({
          points,
          block,
          shade: face.shade,
          depth
        });
      }
    }

    renderFaces.sort((a, b) => b.depth - a.depth);

    for (const face of renderFaces) {
      const alpha =
        face.block.type === "glass" ? 0.48 : 1;

      drawFace(
        face.points,
        face.block,
        face.shade,
        alpha
      );
    }
  }

  // TARGET SYSTEM

  function rayTarget() {
    let best = null;
    let bestScore = Infinity;

    for (const block of world.values()) {
      const center = project(
        block.x,
        block.y,
        block.z
      );

      if (!center || center.depth > 6) continue;

      const dx = center.x - window.innerWidth / 2;
      const dy = center.y - window.innerHeight / 2;

      const score = dx * dx + dy * dy;
      const size = Math.max(
        8,
        window.innerWidth / center.depth * 0.45
      );

      if (score < size * size && score < bestScore) {
        best = block;
        bestScore = score;
      }
    }

    return best;
  }

  function drawTargetMarker(block) {
    if (!block) return;

    const p = project(block.x, block.y, block.z);
    if (!p) return;

    const size = Math.max(
      10,
      window.innerWidth / p.depth * 0.48
    );

    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;

    ctx.strokeRect(
      p.x - size / 2,
      p.y - size / 2,
      size,
      size
    );
  }

  // SKY AND GROUND

  function drawSkyAndGround() {
    const w = window.innerWidth;
    const h = window.innerHeight;

    const sky = ctx.createLinearGradient(0, 0, 0, h);

    sky.addColorStop(0, "#72b8ee");
    sky.addColorStop(0.62, "#c5e4fa");
    sky.addColorStop(0.63, "#83b85c");
    sky.addColorStop(1, "#527d39");

    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
  }

  // PLAYER MOVEMENT

  function movePlayer(dt) {
    const forward =
      (keys.KeyW ? 1 : 0) -
      (keys.KeyS ? 1 : 0) -
      joystick.y;

    const side =
      (keys.KeyD ? 1 : 0) -
      (keys.KeyA ? 1 : 0) +
      joystick.x;

    const length = Math.hypot(forward, side) || 1;

    const f = forward / length;
    const s = side / length;

    const speed = player.speed * dt;

    const nextX =
      player.x +
      (Math.sin(player.yaw) * f +
       Math.cos(player.yaw) * s) * speed;

    const nextZ =
      player.z +
      (-Math.cos(player.yaw) * f +
       Math.sin(player.yaw) * s) * speed;

    if (Math.abs(nextX) < 7.7) player.x = nextX;
    if (Math.abs(nextZ) < 7.7) player.z = nextZ;

    player.verticalSpeed -= 12 * dt;
    player.y += player.verticalSpeed * dt;

    if (player.y <= 1.55) {
      player.y = 1.55;
      player.verticalSpeed = 0;
      player.grounded = true;
    }
  }

  // BLOCK ACTIONS

  function breakTarget() {
    const target = rayTarget();

    if (target && target.y >= 0) {
      removeBlock(target);
      setStatus(`${target.type} block broken.`);
    } else {
      setStatus("No block selected to break.");
    }
  }

  function placeBlock() {
    const target = rayTarget();

    if (!target) {
      setStatus("Select a block first.");
      return;
    }

    const dx = player.x - target.x;
    const dz = player.z - target.z;

    let x = target.x;
    let z = target.z;
    let y = target.y + 1;

    if (Math.abs(dx) > Math.abs(dz)) {
      x += dx > 0 ? 1 : -1;
      y = target.y;
    } else {
      z += dz > 0 ? 1 : -1;
      y = target.y;
    }

    if (
      Math.hypot(x - player.x, z - player.z) < 1.1 &&
      y <= 2
    ) {
      setStatus("You cannot place a block inside the player.");
      return;
    }

    const type = blockSelect
      ? blockSelect.value
      : "grass";

    if (addBlock(x, y, z, type)) {
      setStatus(`${type} block placed.`);
    } else {
      setStatus("A block already exists here.");
    }
  }

  // TOUCH JOYSTICK

  const pad = document.getElementById("movePad");
  const stick = document.getElementById("stick");

  let padPointer = null;

  function updateStick(e) {
    const rect = pad.getBoundingClientRect();

    let dx =
      e.clientX - (rect.left + rect.width / 2);

    let dy =
      e.clientY - (rect.top + rect.height / 2);

    const max = 40;
    const len = Math.hypot(dx, dy);

    if (len > max) {
      dx = dx / len * max;
      dy = dy / len * max;
    }

    joystick.x = dx / max;
    joystick.y = dy / max;

    stick.style.transform =
      `translate(${dx}px, ${dy}px)`;
  }

  if (pad && stick) {
    pad.addEventListener("pointerdown", e => {
      padPointer = e.pointerId;
      pad.setPointerCapture(e.pointerId);
      updateStick(e);
    });

    pad.addEventListener("pointermove", e => {
      if (e.pointerId === padPointer) {
        updateStick(e);
      }
    });

    const release = e => {
      if (e.pointerId !== padPointer) return;

      padPointer = null;
      joystick = { x: 0, y: 0 };
      stick.style.transform = "translate(0,0)";
    };

    pad.addEventListener("pointerup", release);
    pad.addEventListener("pointercancel", release);
  }

  // CAMERA CONTROL

  canvas.addEventListener("pointerdown", e => {
    if (e.clientX < window.innerWidth * 0.38) return;

    lookPointer = e.pointerId;

    lastLook = {
      x: e.clientX,
      y: e.clientY
    };

    canvas.setPointerCapture(e.pointerId);
  });

  canvas.addEventListener("pointermove", e => {
    if (e.pointerId !== lookPointer) return;

    const dx = e.clientX - lastLook.x;
    const dy = e.clientY - lastLook.y;

    lastLook = {
      x: e.clientX,
      y: e.clientY
    };

    player.yaw -= dx * 0.004;

    player.pitch = Math.max(
      -0.8,
      Math.min(0.8, player.pitch - dy * 0.004)
    );
  });

  const stopLook = e => {
    if (e.pointerId === lookPointer) {
      lookPointer = null;
    }
  };

  canvas.addEventListener("pointerup", stopLook);
  canvas.addEventListener("pointercancel", stopLook);

  // KEYBOARD CONTROLS

  window.addEventListener("keydown", e => {
    keys[e.code] = true;

    if (e.code === "Space" && player.grounded) {
      player.verticalSpeed = 5;
      player.grounded = false;
    }

    if (e.code === "KeyE") breakTarget();
    if (e.code === "KeyQ") placeBlock();
  });

  window.addEventListener("keyup", e => {
    keys[e.code] = false;
  });

  // BUTTONS

  function bindClick(id, fn) {
    const element = document.getElementById(id);

    if (element) {
      element.addEventListener("click", fn);
    }
  }

  bindClick("breakBtn", breakTarget);
  bindClick("placeBtn", placeBlock);

  bindClick("upBtn", () => {
    if (player.grounded) {
      player.verticalSpeed = 5;
      player.grounded = false;
    }
  });

  bindClick("resetBtn", () => {
    createWorld();

    player.x = 0.5;
    player.y = 1.55;
    player.z = 5.5;
    player.yaw = 0;
    player.pitch = 0;
    player.verticalSpeed = 0;
    player.grounded = true;

    setStatus("World reset.");
  });

  // GAME LOOP

  function frame(now) {
    const dt = Math.min(
      (now - lastFrame) / 1000,
      0.04
    );

    lastFrame = now;

    movePlayer(dt);
    drawSkyAndGround();
    renderWorld();

    const target = rayTarget();
    drawTargetMarker(target);

    if (coordsEl) {
      coordsEl.textContent =
        `X: ${player.x.toFixed(1)} | Z: ${player.z.toFixed(1)}`;
    }

    requestAnimationFrame(frame);
  }

  // START GAME

  createWorld();

  setStatus("YUNIX 3D GAME v0.2 is ready!");

  requestAnimationFrame(frame);

  console.log("YUNIX 3D GAME v0.2 started.");
  alert("YUNIX 3D GAME JavaScript is running!");
})();