using UnityEngine;

public class WorldGenerator : MonoBehaviour
{
    public int worldSize = 16;
    public int maxHeight = 6;
    public float noiseScale = 0.15f;

    private Material grassMaterial;
    private Material dirtMaterial;

    void Start()
    {
        CreateMaterials();
        GenerateWorld();
    }

    void CreateMaterials()
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");

        if (shader == null)
            shader = Shader.Find("Standard");

        grassMaterial = new Material(shader);
        grassMaterial.color = new Color(0.25f, 0.65f, 0.2f);

        dirtMaterial = new Material(shader);
        dirtMaterial.color = new Color(0.45f, 0.25f, 0.12f);
    }

    void GenerateWorld()
    {
        for (int x = 0; x < worldSize; x++)
        {
            for (int z = 0; z < worldSize; z++)
            {
                float noise = Mathf.PerlinNoise(
                    x * noiseScale,
                    z * noiseScale
                );

                int height = Mathf.FloorToInt(
                    noise * maxHeight
                ) + 1;

                for (int y = 0; y < height; y++)
                {
                    GameObject block =
                        GameObject.CreatePrimitive(
                            PrimitiveType.Cube
                        );

                    block.name = y == height - 1
                        ? "Grass_Block"
                        : "Dirt_Block";

                    block.transform.SetParent(transform);

                    block.transform.localPosition =
                        new Vector3(x, y, z);

                    Renderer rend =
                        block.GetComponent<Renderer>();

                    rend.sharedMaterial =
                        y == height - 1
                        ? grassMaterial
                        : dirtMaterial;
                }
            }
        }

        Debug.Log("YUNIX 3D GAME: Dünya oluşturuldu!");
    }
}