`
using UnityEngine;

public class BlockSystem : MonoBehaviour
{
    public Camera playerCamera;
    public float reachDistance = 5f;

    public GameObject grassBlockPrefab;
    public GameObject dirtBlockPrefab;

    public void BreakBlock()
    {
        if (Physics.Raycast(
            playerCamera.transform.position,
            playerCamera.transform.forward,
            out RaycastHit hit,
            reachDistance))
        {
            if (hit.collider.CompareTag("Block"))
            {
                Destroy(hit.collider.gameObject);
                Debug.Log("YUNIX: Block broken!");
            }
        }
    }

    public void PlaceGrassBlock()
    {
        PlaceBlock(grassBlockPrefab);
    }

    public void PlaceDirtBlock()
    {
        PlaceBlock(dirtBlockPrefab);
    }

    void PlaceBlock(GameObject prefab)
    {
        if (prefab == null || playerCamera == null)
            return;

        if (Physics.Raycast(
            playerCamera.transform.position,
            playerCamera.transform.forward,
            out RaycastHit hit,
            reachDistance))
        {
            Vector3 position =
                hit.collider.transform.position +
                hit.normal;

            position = new Vector3(
                Mathf.Round(position.x),
                Mathf.Round(position.y),
                Mathf.Round(position.z)
            );

            Instantiate(prefab, position, Quaternion.identity);
        }
    }
}
