
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    public float jumpHeight = 1.5f;
    public float gravity = -20f;

    public MobileControls mobile;

    private CharacterController controller;
    private Vector3 velocity;

    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        if (mobile != null)
        {
            if (Mathf.Abs(mobile.horizontal) > 0.01f ||
                Mathf.Abs(mobile.vertical) > 0.01f)
            {
                x = mobile.horizontal;
                z = mobile.vertical;
            }
        }

        Vector3 move = transform.right * x +
                       transform.forward * z;

        controller.Move(
            move * speed * Time.deltaTime
        );

        if (controller.isGrounded && velocity.y < 0)
            velocity.y = -2f;

        bool jump = Input.GetButtonDown("Jump");

        if (mobile != null && mobile.GetJump())
            jump = true;

        if (controller.isGrounded && jump)
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

        velocity.y += gravity * Time.deltaTime;

        controller.Move(
            velocity * Time.deltaTime
        );
    }
}
