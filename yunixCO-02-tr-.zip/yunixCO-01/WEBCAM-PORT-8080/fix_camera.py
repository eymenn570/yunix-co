from pathlib import Path

p = Path("server.py")
s = p.read_text(encoding="utf-8")

start = s.index('CAPTURE_PAGE = r"""')
end = s.index('"""', start + len('CAPTURE_PAGE = r"""'))

page = '''CAPTURE_PAGE = r"""
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VXC Kamera Kaynağı</title>
<style>
body{font:16px Arial;background:#101827;color:white;padding:18px}
video{width:100%;max-width:600px;background:#000;border-radius:12px}
button,a{padding:12px;background:#2563eb;color:white;border:0;border-radius:8px;text-decoration:none;display:inline-block;margin:5px 0}
</style>
</head>
<body>
<h1>VXC Kamera Kaynağı</h1>
<p>Kamera izni ver ve başlat düğmesine bas.</p>
<video id="video" autoplay playsinline muted></video>
<p id="msg">Kamera henüz başlamadı.</p>
<button id="start" type="button">Kamerayı başlat</button>
<p><a href="/">Kontrol paneline dön</a></p>
<canvas id="canvas" hidden></canvas>
<script>
const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const msg = document.getElementById("msg");
let running = false;

document.getElementById("start").onclick = async function() {
  msg.textContent = "Başlat düğmesine basıldı!";
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error("Kamera için Chrome'da localhost veya HTTPS kullan.");
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {facingMode: "environment"},
      audio: false
    });
    video.srcObject = stream;
    await video.play();
    running = true;
    msg.textContent = "Kamera çalışıyor.";
    sendFrame();
  } catch (e) {
    msg.textContent = "Kamera açılamadı: " + e.message;
  }
};

async function sendFrame() {
  if (!running) return;
  try {
    if (video.readyState >= 2 && video.videoWidth > 0) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);
      const blob = await new Promise(resolve =>
        canvas.toBlob(resolve, "image/jpeg", 0.7)
      );
      if (blob) {
        await fetch("/frame", {
          method: "POST",
          headers: {"Content-Type": "image/jpeg"},
          body: blob
        });
      }
    }
  } catch (e) {
    msg.textContent = "Görüntü gönderilemedi: " + e.message;
  }
  if (running) setTimeout(sendFrame, 500);
}
</script>
</body>
</html>
"""'''

p.write_text(s[:start] + page + s[end + 3:], encoding="utf-8")
print("Kamera sayfası düzeltildi.")