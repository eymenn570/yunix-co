
import os
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

BASE_DIR = os.path.join(os.path.dirname(__file__), "ftp_shared")
os.makedirs(BASE_DIR, exist_ok=True)

authorizer = DummyAuthorizer()
authorizer.add_user(
    "yunix",
    "ftp",
    BASE_DIR,
    perm="elradfmw"
)

handler = FTPHandler
handler.authorizer = authorizer
handler.passive_ports = range(30000, 30010)

server = FTPServer(("0.0.0.0", 8080), handler)

print("Yunix CO FTP Server is working!")
print("Port: 8080")
print("Folder:", BASE_DIR)
print("To stop  CTRL+C")

server.serve_forever()

