
#!/data/data/com.termux/files/usr/bin/bash

WEBCAM="$HOME/yunix-co-webcam-port-8080"
FTP="$HOME/YUNIX-CO/ftp/server.js"
MODEM="$HOME/YUNIX-CO/modem/modem.php"

while true; do
    SECIM=$(dialog \
        --clear \
        --title "YUNIX CO" \
        --menu "Bir modül seç:" \
        18 48 6 \
        1 "Webcam Port 8080" \
        2 "Yunix CO FTP" \
        3 "Modem Software (PHP)" \
        4 "Yunix CO MOD MENU" \
        0 "Çıkış" \
        3>&1 1>&2 2>&3)

    SONUC=$?
    clear

    if [ "$SONUC" -ne 0 ]; then
        break
    fi

    case "$SECIM" in
        1)
            if [ -f "$WEBCAM/server.py" ]; then
                cd "$WEBCAM" || continue
                python server.py
            else
                echo "Webcam dosyası bulunamadı."
            fi
            read -r -p "Menüye dönmek için Enter..."
            ;;

        2)
            if [ -f "$FTP" ]; then
                node "$FTP"
            else
                echo "FTP dosyası bulunamadı: $FTP"
            fi
            read -r -p "Menüye dönmek için Enter..."
            ;;

        3)
            if [ -f "$MODEM" ]; then
                php "$MODEM"
            else
                echo "Modem PHP dosyası bulunamadı: $MODEM"
            fi
            read -r -p "Menüye dönmek için Enter..."
            ;;

        4)
            MOD=$(dialog \
                --clear \
                --title "YUNIX CO MOD MENU" \
                --menu "Bir işlem seç:" \
                12 45 3 \
                1 "PHP Mode" \
                2 "Address List" \
                0 "Geri dön" \
                3>&1 1>&2 2>&3)
         





            clear

            case "$MOD" in
                1)
                    if [ -f "$MODEM" ]; then
                        php "$MODEM"
                    else
                        echo "Modem PHP dosyası bulunamadı."
                    fi
                    read -r -p "Menüye dönmek için Enter..."
                    ;;
                2)
                    echo "YUNIX CO ADDRESS LIST"
                    echo "192.168.1.1"
                    echo "192.168.0.1"
                    echo "192.168.2.1"
                    echo "10.0.0.1"
                    read -r -p "Menüye dönmek için Enter..."
                    ;;
            esac
            ;;

        0)
            break
            ;;
    esac
done

clear
echo "YUNIX CO kapatıldı."

