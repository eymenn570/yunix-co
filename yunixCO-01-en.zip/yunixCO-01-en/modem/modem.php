<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

const DEFAULT_MODEM_IP = '192.168.1.1';
const MODEM_SCHEME = 'https';

$modemIp = DEFAULT_MODEM_IP;

function phpError(string $type, string $message, int $code): void
{
    echo "\n";
    echo "================================\n";
    echo "       YUNIX CO PHP ERROR\n";
    echo "================================\n";
    echo "PHP {$type}: {$message}\n";
    echo "Error Code: {$code}\n";
    echo "================================\n";
}

function pauseScreen(): void
{
    echo "\nEnter to continue...";
    fgets(STDIN);
}

function runCommand(array $command, int $timeout = 8): array
{
    $process = proc_open(
        $command,
        [
            0 => ['file', '/dev/null', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ],
        $pipes
    );

    if (!is_resource($process)) {
        return [false, '', 'The operation could not be started.'];
    }

    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);

    $stdout = '';
    $stderr = '';
    $start = time();
    $timedOut = false;

    while (true) {
        $stdout .= stream_get_contents($pipes[1]);
        $stderr .= stream_get_contents($pipes[2]);

        $status = proc_get_status($process);

        if (!$status['running']) {
            break;
        }

        if (time() - $start >= $timeout) {
            proc_terminate($process);
            $timedOut = true;
            break;
        }

        usleep(100000);
    }

    $stdout .= stream_get_contents($pipes[1]);
    $stderr .= stream_get_contents($pipes[2]);

    fclose($pipes[1]);
    fclose($pipes[2]);

    $exitCode = proc_close($process);

    if ($timedOut) {
        return [false, $stdout, 'The process timed out.'];
    }

    if ($exitCode !== 0 && $stdout === '') {
        return [false, $stdout, trim($stderr) ?: 'The command failed.'];
    }

    return [true, $stdout, $stderr];
}

function checkModem(string $ip): void
{
    echo "\n The modem is being checked.: {$ip}\n";

    [$ok, $output, $error] = runCommand([
        'curl', '-k', '-sS', '-I',
        '--max-time', '5',
        MODEM_SCHEME . '://' . $ip . '/'
    ], 7);

    if (!$ok) {
        phpError('Warning', 'The modem could not be reached: ' . $error, 1001);
        return;
    }

    echo $output;
    echo "\n A response was received from the modem web server.\n";
}

function checkInternet(): void
{
    echo "\n Testing internet connection...\n";

    [$ok, $output, $error] = runCommand([
        'curl', '-sS', '-L',
        '--max-time', '8',
        '-o', '/dev/null',
        '-w', 'HTTP code: %{http_code}\n',
        'https://example.com'
    ], 10);

    if (!$ok) {
        phpError('Warning', 'Internet request failed. : ' . $error, 1002);
        return;
    }

    echo $output;
    echo "Request completed. \n";
}

function openModem(string $ip): void
{
    $url = MODEM_SCHEME . '://' . $ip . '/';

    [$ok, $output, $error] = runCommand([
        'am', 'start',
        '-a', 'android.intent.action.VIEW',
        '-d', $url
    ], 5);

    if (!$ok) {
        phpError('Warning', 'The browser did not open: ' . $error, 1003);
        return;
    }

    echo "A request to turn on the modem panel has been sent: {$url}\n";
}

function showCertificate(string $ip): void
{
    echo "\nSSL certificate information: {$ip}\n";

    [$ok, $output, $error] = runCommand([
        'openssl', 's_client',
        '-connect', $ip . ':443',
        '-servername', $ip
    ], 5);

    if (!$ok && trim($output) === '') {
        phpError('Warning', 'The certificate connection could not be established.', 1004);
        return;
    }

    // Sertifika ayrıntılarını ayrı bir komutla al.
    [$certOk, $certOutput, $certError] = runCommand([
        'sh', '-c',
        'openssl s_client -connect "$1:443" -servername "$1" </dev/null 2>/dev/null | openssl x509 -noout -subject -issuer -dates -fingerprint -sha256',
        'sh', $ip
    ], 8);

    if (!$certOk || trim($certOutput) === '') {
        phpError('Warning', 'The certificate could not be read: ' . $certError, 1005);
        return;
    }

    echo $certOutput;
}

function chooseAddress(string &$ip): void
{
    while (true) {
        echo "\n";
        echo "================================\n";
        echo " ADDRESS CHANGE CHANNEL LIST\n";
        echo "================================\n";
        echo "Aktif adres: {$ip}\n\n";
        echo "1. 192.168.1.1 (Türkiye widespread)\n";
        echo "2. 192.168.0.1 (Türkiye alternative (1))\n";
        echo "3. 192.168.2.1 (Türkiye alternative (2))\n";
        echo "4. 10.0.0.1 (USA widespread)\n";
        echo "0. Come back\n\n";
        echo "Address selection: ";

        $choice = trim(fgets(STDIN));

        $addresses = [
            '1' => '192.168.1.1',
            '2' => '192.168.0.1',
            '3' => '192.168.2.1',
            '4' => '10.0.0.1',
        ];

        if ($choice === '0') {
            return;
        }

        if (isset($addresses[$choice])) {
            $ip = $addresses[$choice];
            echo "Target address selected.: {$ip}\n";
            echo "Note: This selection does not change modem settings.\n";
            return;
        }

        phpError('Notice', 'Invalid address selection..', 2001);
    }
}

while (true) {
    if (function_exists('system')) {
        system('clear');
    }

    echo "================================\n";
    echo "    YUNIX CO MODEM SOFTWARE\n";
    echo "================================\n";
    echo "Modem address: {$modemIp}\n\n";
    echo "1. Check the modem address.\n";
    echo "2. Internet connection test.\n";
    echo "3. Modem control panel open ";
    echo "4. Show modem SSL certificate\n";
    echo "5. Address Changing Mode\n";
    echo "0. Ana menüye dön\n\n";
    echo "Your choice: ";

    $choice = trim(fgets(STDIN));

    switch ($choice) {
        case '1':
            checkModem($modemIp);
            pauseScreen();
            break;

        case '2':
            checkInternet();
            pauseScreen();
            break;

        case '3':
            openModem($modemIp);
            pauseScreen();
            break;

        case '4':
            showCertificate($modemIp);
            pauseScreen();
            break;

        case '5':
            chooseAddress($modemIp);
            break;

        case '0':
            exit(0);

        default:
            phpError('Notice', 'Invalid menu selection..', 2001);
            sleep(1);
    }
}