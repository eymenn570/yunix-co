#!/data/data/com.termux/files/usr/bin/bash

MODEM_IP="192.168.1.1"
MODEM_SCHEME="https"

while true; do
    MODEM_URL="$MODEM_SCHEME://$MODEM_IP/"

    clear
    echo "================================"
    echo "    YUNIX CO MODEM SOFTWARE"
    echo "================================"
    echo "Modem address: $MODEM_IP"
    echo
    echo "1. Check the modem address"
    echo "2. Test your internet connection"
    echo "3. Open the modem control panel"
    echo "4. Show modem SSL certificate"
    echo "5. Address Changing Mode"
    echo "0. Return to the main menu"
    echo

    read -r -p "Your choice: " vote

    case "$vote" in
        1)
            echo
            if curl -k -sS -I --max-time 5 "$MODEM_URL"; then
                echo
                echo "Modem A response was received from the web server."
            else
                echo "Modeme could not reach."
            fi
            read -r -p "To continue Enter..."
            ;;
        2)
            echo
            if curl -sS -L --max-time 8 \
                -o /dev/null \
                -w "HTTP code: %{http_code}\n" \
                https://example.com; then
                echo "Internet request completed. "
            else
                echo "İnternet bağlantısı test edilemedi."
            fi
            read -r -p "To continue Enter..."
            ;;
        3)
            am start -a android.intent.action.VIEW -d "$MODEM_URL"
            read -r -p "To continue Enter..."
            ;;
        4)
            echo
            echo "Certificate information:"
            if command -v openssl >/dev/null 2>&1; then
                timeout 8 openssl s_client \
                    -connect "$MODEM_IP:443" \
                    -servername "$MODEM_IP" \
                    </dev/null 2>/dev/null |
                openssl x509 -noout \
                    -subject -issuer -dates -fingerprint -sha256
            else
                echo "OpenSSL not installed. To set up: pkg install openssl"
            fi
            read -r -p "To continue Enter..."
            ;;
        5)
            while true; do
                clear
                echo "================================"
                echo " ADDRESS CHANGE CHANNEL LIST"
                echo "================================"
                echo "Aktif adres: $MODEM_IP"
                echo
                echo "1. 192.168.1.1 (TURKEY 1)"
                echo "2. 192.168.0.1 (TURKEY 2)"
                echo "3. 192.168.2.1 (TURKEY 3)"
                echo "4. 10.0.0.1 (AMERICA 1)"
                echo "0. Geri dön"
                echo

                read -r -p "Address selection: " adres_secim

                case "$adres_secim" in
                    1)
                        MODEM_IP="192.168.1.1"
                        echo "Address selected: $MODEM_IP"
                        break
                        ;;
                    2)
                        MODEM_IP="192.168.0.1"
                        echo "Address selected: $MODEM_IP"
                        break
                        ;;
                    3)
                        MODEM_IP="192.168.2.1"
                        echo "Address selected: $MODEM_IP"
                        break
                        ;;

                    4)
                        MODEM_IP="10.0.0.1"
                        echo "Address selected: $MODEM_IP"
                        break
                        ;;

                    0)
                        break
                        ;;
                    *)
                        echo "Invalid election!"
                        sleep 1
                        ;;
                esac
            done
            ;;
        0)
            exit 0
            ;;
        *)
            echo "Invalid election!"
            sleep 1
            ;;
    esac
done